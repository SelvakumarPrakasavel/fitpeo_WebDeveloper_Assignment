import { useState } from 'react'
import './App.css'

function App() {
  const [count, setCount] = useState(0)

  return (
    <div className="dashboard">
<div className="div">
<div className="earning">
<div className="overlap-group">
<div className="group">
<div className="group-2">
<div className="text-wrapper">Earning</div>
<div className="text-wrapper-2">$198k</div>
<div className="money-recive-wrapper">
<img className="img" alt="Money recive" src="money-recive-1.svg" />
</div>
<div className="group-3">
<p className="p">
<span className="span">37.8%</span>
<span className="text-wrapper-3"> this month</span>
</p>
<img className="arrow-up" alt="Arrow up" src="arrow-up-1.svg" />
</div>
</div>
<div className="group-4">
<div className="text-wrapper">Balance</div>
<div className="text-wrapper-2">$2.4k</div>
<div className="wallet-money-wrapper">
<img className="img" alt="Wallet money" src="wallet-money-1.svg" />
</div>
<div className="group-5">
<p className="p">
<span className="text-wrapper-4">2%</span>
<span className="text-wrapper-3"> this month</span>
</p>
<img className="arrow-up" alt="Arrow up" src="arrow-up-1-2.svg" />
</div>
</div>
<div className="group-6">
<div className="text-wrapper">Total Sales</div>
<div className="text-wrapper-2">$89k</div>
<div className="bag-wrapper">
<img className="bag" alt="Bag" src="bag-2-1.svg" />
</div>
<div className="group-7">
<p className="p">
<span className="span">11%</span>
<span className="text-wrapper-3"> this week</span>
</p>
<img className="arrow-up" alt="Arrow up" src="arrow-up-1-3.svg" />
</div>
</div>
<img className="line" alt="Line" src="line-2.svg" />
<img className="line-2" alt="Line" src="line-3.svg" />
</div>
</div>
</div>
<div className="overview">
<div className="overlap">
<div className="overlap-group-wrapper">
<div className="overlap-group-2">
<img className="chevron-down" alt="Chevron down" src="chevron-down-1-2.svg" />
<div className="text-wrapper-5">Quarterly</div>
</div>
</div>
<div className="text-wrapper-6">Overview</div>
<div className="text-wrapper-7">Monthly Earning</div>
<div className="text-wrapper-8">Jan</div>
<div className="text-wrapper-9">Feb</div>
<div className="text-wrapper-10">Mar</div>
<div className="text-wrapper-11">Apr</div>
<div className="text-wrapper-12">May</div>
<div className="text-wrapper-13">Jun</div>
<div className="text-wrapper-14">Jul</div>
<div className="text-wrapper-15">Aug</div>
<div className="text-wrapper-16">Sep</div>
<div className="text-wrapper-17">Oct</div>
<div className="text-wrapper-18">Nov</div>
<div className="text-wrapper-19">Dec</div>
<div className="rectangle" />
<div className="rectangle-2" />
<div className="rectangle-3" />
<div className="rectangle-4" />
<div className="rectangle-5" />
<div className="rectangle-6" />
<div className="rectangle-7" />
<div className="rectangle-8" />
<div className="rectangle-9" />
<div className="rectangle-10" />
<div className="rectangle-11" />
<div className="rectangle-12" />
<div className="group-wrapper">
<div className="group-8">
<div className="text-wrapper-20">35%</div>
<div className="vector-wrapper">
<img className="vector" alt="Vector" src="vector-2.svg" />
</div>
</div>
</div>
</div>
</div>
<div className="customers">
<div className="overlap-2">
<div className="text-wrapper-6">Customers</div>
<div className="text-wrapper-21">Customers that buy products</div>
<div className="overlap-group-3">
<div className="ellipse" />
<img className="ellipse-2" alt="Ellipse" src="ellipse-6.svg" />
<img className="ellipse-3" alt="Ellipse" src="ellipse-7.svg" />
<p className="element-total-new">
<span className="text-wrapper-22">
65%
<br />
</span>
<span className="text-wrapper-23">Total New Customers</span>
</p>
</div>
</div>
</div>
<div className="product">
<div className="overlap-3">
<div className="text-wrapper-24">Product Sell</div>
<div className="group-9">
<div className="text-wrapper-25">32 in stock</div>
<div className="text-wrapper-26">$ 45.99</div>
<div className="text-wrapper-27">20</div>
<div className="group-10">
<div className="text-wrapper-28">Abstract 3D</div>
<p className="text-wrapper-29">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
<img className="img-2" alt="Unsplash eo" src="images.jpg" />
</div>
</div>
<div className="group-11">
<div className="text-wrapper-28">Sarphens Illustration</div>
<div className="text-wrapper-25">32 in stock</div>
<div className="text-wrapper-26">$ 45.99</div>
<div className="text-wrapper-27">20</div>
<p className="text-wrapper-29">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
<img className="img-2" alt="Unsplash namzag" src="images1.jpg" />
</div>
<div className="group-14">
<div className="group-15">
<div className="text-wrapper-30">Product Name</div>
<div className="text-wrapper-31">Stock</div>
<div className="text-wrapper-32">Price</div>
<div className="text-wrapper-33">Total Sales</div>
</div>
<img className="line-3" alt="Line" src="line-4.svg" />
</div>
<div className="div-wrapper">
<div className="overlap-group-4">
<div className="text-wrapper-34">Search</div>
<img className="search" alt="Search" src="search-1.svg" />
</div>
</div>
<div className="overlap-wrapper">
<div className="overlap-4">
<img className="chevron-down-2" alt="Chevron down" src="chevron-down-1.svg" />
<div className="text-wrapper-35">Last 30 days</div>
</div>
</div>
</div>
</div>
<div className="search-2">
<div className="overlap-5">
<input className="input" placeholder="Search" type="text" />
<img className="search" alt="Search" src="search-1-2.svg" />
</div>
</div>
<div className="side-menu">
<div className="overlap-6">
<div className="list-menu-wrapper">
<div className="list-menu">
<img className="img-3" alt="Icon outline key" src="key-square.svg" />
<div className="text-wrapper-36">Dashboard</div>
</div>
</div>
<div className="list-menu-2">
<img className="img-3" alt="Element square" src="3d-square-1.svg" />
<div className="text-wrapper-37">Product</div>
<img className="chevron-right" alt="Chevron right" src="chevron-right-2.svg" />
</div>
<div className="list-menu-3">
<img className="img-3" alt="User square" src="user-square-1.svg" />
<div className="text-wrapper-37">Customers</div>
<img className="chevron-right" alt="Chevron right" src="image.svg" />
</div>
<div className="list-menu-4">
<img className="img-3" alt="Wallet money" src="wallet-money-2.svg" />
<div className="text-wrapper-37">Income</div>
<img className="chevron-right" alt="Chevron right" src="chevron-right-2-2.svg" />
</div>
<div className="list-menu-5">
<img className="img-3" alt="Discount shape" src="discount-shape-1.svg" />
<div className="text-wrapper-37">Promote</div>
<img className="chevron-right" alt="Chevron right" src="chevron-right-2-3.svg" />
</div>
<div className="list-menu-6">
<img className="img-3" alt="Message question" src="message-question-1.svg" />
<div className="text-wrapper-37">Help</div>
<img className="chevron-right" alt="Chevron right" src="chevron-right-2-4.svg" />
</div>
<img className="ellipse-4" alt="Ellipse" src="ellipse-8.png" />
<div className="group-16">
<div className="overlap-group-5">
<div className="text-wrapper-38">Selvakumar</div>
<div className="text-wrapper-39">Software Developer</div>
<div style={{width: '100%', height: '100%', backgroundColor: 'blue', boxShadow: '0px 10px 60px rgba(225.83, 236.19, 248.63, 0.50)'}} />
</div>
</div>
<img className="chevron-down-3" alt="Chevron down" src="chevron-right-2.svg" />
<div className="access-pro">
<div className="overlap-7">
<button className="CTA">
<div className="overlap-group-6">
<div className="text-wrapper-40"></div>
</div>
</button>
</div>
</div>
<div className="group-17">
<div className="text-wrapper-41">Dashboard</div>
<img className="setting" alt="Setting" src="setting-1.svg" />
</div>
<div className="text-wrapper-42"></div>
</div>
</div>
<div className="text-wrapper-43">Hello Selvakumar,</div>
</div>
</div>
  )
}
export default App
