import React from 'react'
import "../src/App.css"

export default function Sidebar() {
  return (
    <div className="side-menu">
    <div className="overlap-6">
    <div className="list-menu-wrapper">
    <div className="list-menu">
    <img className="img-3" alt="Icon outline key" src="key-square.svg" />
    <div className="text-wrapper-36">Dashboard</div>
    </div>
    </div>
    <div className="list-menu-2">
    <img className="img-3" alt="Element square" src="3d-square-1.svg" />
    <div className="text-wrapper-37">Product</div>
    <img className="chevron-right" alt="Chevron right" src="chevron-right-2.svg" />
    </div>
    <div className="list-menu-3">
    <img className="img-3" alt="User square" src="user-square-1.svg" />
    <div className="text-wrapper-37">Customers</div>
    <img className="chevron-right" alt="Chevron right" src="image.svg" />
    </div>
    <div className="list-menu-4">
    <img className="img-3" alt="Wallet money" src="wallet-money-2.svg" />
    <div className="text-wrapper-37">Income</div>
    <img className="chevron-right" alt="Chevron right" src="chevron-right-2-2.svg" />
    </div>
    <div className="list-menu-5">
    <img className="img-3" alt="Discount shape" src="discount-shape-1.svg" />
    <div className="text-wrapper-37">Promote</div>
    <img className="chevron-right" alt="Chevron right" src="chevron-right-2-3.svg" />
    </div>
    <div className="list-menu-6">
    <img className="img-3" alt="Message question" src="message-question-1.svg" />
    <div className="text-wrapper-37">Help</div>
    <img className="chevron-right" alt="Chevron right" src="chevron-right-2-4.svg" />
    </div>
    <img className="ellipse-8" alt="Ellipse" src="images.jpg" />
    <div className="group-16">
    <div className="overlap-group-5">
    <div className="text-wrapper-38">Selvakumar</div>
    <div className="text-wrapper-39">Software Developer</div>
    </div>
    </div>
    <div className="access-pro">
    <div className="osverlap-7">
    </div>
    </div>
    <div className="group-17">
    <div className="text-wrapper-41">Dashboard</div>
    <img className="setting" alt="Setting" src="setting-1.svg" />
    </div>
    </div>
    </div>
  )
}
